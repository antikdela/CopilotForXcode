# No-Recoil

No Recoil is a very simple open source application for reducing recoil in games.

Before using this program please check if the game you want to use it in does not detect programs that are using mouse_event as cheats.

1. Download or compile the program
2. Run the program
3. Set your options so it fits the game and your mouse sensitivity
4. Use insert key to activate/deactivate recoil control
<h4 align="center">
  <hr>
<img src="https://raw.githubusercontent.com/roast247/No-Recoil/main/norecoil.PNG">
<hr>
Disclaimer: I am not resposible for any illegal actions with the use of my programs

  If you would like to contact me, email me at https://roast247.eu.org/contact.php
</h4>

<h4 align="center">

  
  ![Your Repository's Stats](https://github-readme-stats.vercel.app/api?username=roast247&show_icons=true)


</h4>
